C3
==
index.html:contains the sitemap.

friends.html: contains a list of users that are "friends" of the "logged in" user, javascript is used to generate the table of friends.( followers.html and gallery.html are very similar also)
)

login.html: contains a login form.

register.html: contains a register form.

photo.html: a generic photo page with a comments section.

user.html: a generic user page with a javascript generated sample gallery.

Form validation: login.js, register.js, photo.js:

-used to detect if there are sufficient values to submit.
-login,register and photo.js used as their html counterparts are the only ones that have forms.

CSS techniques: style.css:

-link highlighting done throughout the website.
-general positioning done through css.

